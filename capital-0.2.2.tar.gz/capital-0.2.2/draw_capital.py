#!/usr/bin/env python

import argparse
import os
import sys
from tqdm import tqdm
import scanpy as sc
import numpy as np

import main

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage='./draw_capital.py [option]* <alignment> <genes>',
        description='draw_capital.py ver. 0.2.2\n\nRequired packages: leidenalg, pygraphviz, scanpy>=1.5 and tslearn.\n\nThis script is used to draw figures on dynamic time warping and/or expression dynamics for a gene in aligned_data.\nUsers have to run capital.py before using this.'
    )
    parser.add_argument('alignment', metavar='alignment <STR>', type=str,
                        help='path to the directory for aligned data generated with capital.py (e.g. ./aligned_data/data1_data2/alignment000/)')
    parser.add_argument('genes', metavar='genes <STR>', type=str,
                        help='path to the file that contains gene names to be analyzed (one gene per line)')
    parser.add_argument('--dtw', metavar='<STR>', type=str, default=None,
                        help='path to the directory for a figure on dynamic time warping. unless specified, the figure will be saved in each gene file in the alignment directory.')
    parser.add_argument('--dyn', metavar='<STR>', type=str, default=None,
                        help='path to the directory for a figure on gene expression dynamics. unless specified, the figure will be saved in each gene file in the alignment directory.')
    parser.add_argument('--data1-name', metavar='<STR>', type=str, default=None,
                        help='data1 name on the plot')
    parser.add_argument('--data2-name', metavar='<STR>', type=str, default=None,
                        help='data2 name on the plot')
    # Hidden option for inline plotting of the figures on dynamic time warping and gene expression dynamics
    parser.add_argument('--inline', action='store_true',
                        help=argparse.SUPPRESS)
    args = parser.parse_args()

    if not os.path.isdir(args.alignment):
        print('ERROR: {} does not exit.'.format(args.alignment))
        print('Please select path like ./aligned_data/data1_data2/alignment001/.\n')
        sys.exit()
    
    if not os.path.isfile(args.genes):
        print('ERROR: {} does not exit.'.format(args.genes))
        sys.exit()

    # reading genes file
    if os.path.splitext(args.genes)[1][1:] == "tsv":
        genes = pd.read_table(args.genes, header=None)[0].values.tolist()
    
    elif os.path.splitext(args.genes)[1][1:] == "csv":
        genes = pd.read_csv(args.genes, header=None)[0].values.tolist()
    
    elif os.path.splitext(args.genes)[1][1:] == "txt":
        with open(args.genes, 'r') as f:
            genes = [s.strip() for s in f.readlines()]
    
    else:
        print("ERROR: genes file must be text, csv or tsv.")
        sys.exit()

    # removing input genes that do not exist in alignment.
    non_genes = []

    for gene in genes[:]:
        if not os.path.isdir(os.path.join(args.alignment, gene)):
            non_genes.append(gene)
            genes.remove(gene)
    
    if len(non_genes) > 0:
        print("WARNING: genes below do not exist in the directory {}.".format(
            args.alignment))
        print(non_genes)
        print("")
    
    if len(genes) == 0:
        print("ERROR: genes in the gene file do not exist in the directory {}.".format(
            args.alignment))
        sys.exit()

    if args.dtw:
        if not os.path.isdir(args.dtw):
            os.makedirs(args.dtw, exist_ok=True)

    if args.dyn:
        if not os.path.isdir(args.dyn):
            os.makedirs(args.dyn, exist_ok=True)

    for gene in tqdm(genes, desc='Progress'):
        alignment_data = np.load(os.path.join(
            args.alignment, gene ,"alignment_data.npz"), allow_pickle=True)

        genename = alignment_data["dtwdata"][0][0]
        filtered_data1_path = os.path.join(
            args.alignment, alignment_data["dtwdata"][1][0])
        filtered_data2_path = os.path.join(
            args.alignment, alignment_data["dtwdata"][2][0])
        path = alignment_data["dtwdata_path"].tolist()
        cluster_list = alignment_data["dtwdata_cluster"].tolist()
        colors1 = alignment_data["colors1"].tolist()
        colors2 = alignment_data["colors2"].tolist()
        ordered_cells1 = alignment_data["ordered_cells1"]
        ordered_cells2 = alignment_data["ordered_cells2"]

        if not os.path.isfile(filtered_data1_path):
            print('ERROR: {} does not exit.'.format(filtered_data1_path))
            sys.exit()
        
        if not os.path.isfile(filtered_data2_path):
            print('ERROR: {} does not exit.'.format(filtered_data2_path))
            sys.exit()

        data1 = sc.read(filtered_data1_path)
        data2 = sc.read(filtered_data2_path)

        if args.dtw:
            dir_dtw = args.dtw
        
        else:
            dir_dtw = os.path.join(args.alignment, gene)

        if args.dyn:
            dir_dyn = args.dyn
        
        else:
            dir_dyn = os.path.join(args.alignment, gene)
        
        drawing = main.Drawing()
        drawing.draw_dtw_graph(genename, cluster_list, data1, data2, path, colors1, colors2, ordered_cells1, ordered_cells2,
                            data1_name=args.data1_name, data2_name=args.data2_name, inline=args.inline, dir_fig=dir_dtw)

        drawing.draw_gene_expression_comparison(genename, cluster_list, data1, data2, path, ordered_cells1, ordered_cells2,
                                                data1_name=args.data1_name, data2_name=args.data2_name, inline=args.inline, dir_fig=dir_dyn)
    
    print("\nDrawing completed.")
