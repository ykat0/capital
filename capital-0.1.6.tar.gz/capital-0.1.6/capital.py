#!/usr/bin/env python

import main
import argparse
import os
import sys
from tqdm import tqdm
import itertools
import networkx as nx
import csv

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage='./capital.py [option]* <data1> <data2> <root1> <root2> <genes>',
        description='capital.py ver. 0.1.6\n\nRequired packages: leidenalg, matplotlib, networkx>=2.4, numpy, pandas, scanpy, scikit-learn, scipy and tslearn.\n\nThis script is used to predict pseudotime trajectories for two preprocessed data and compute a trajectory alignment.\nUsers have to run pre_capital.py for each each experiment before using this.'
    )
    parser.add_argument('data1', metavar='data1 <STR>', type=str,
                        help='path to the preprocessed expression H5AD data for experiment 1 generated with pre_capital.py')
    parser.add_argument('data2', metavar='data2 <STR>', type=str,
                        help='path to the preprocessed expression H5AD data for experiment 2 generated with pre_capital.py')
    parser.add_argument('root1', metavar='root1 <STR>', type=str,
                        help='root cluster in data1')
    parser.add_argument('root2', metavar='root2 <STR>', type=str,
                        help='root cluster in data2')
    parser.add_argument('genes', metavar='genes <STR>', type=str,
                        help='path to the file that contains gene names to be analyzed (one gene per line)')
    parser.add_argument('-g','--gapcost', metavar='<INT>', type=int, default=3,
                        help='gap cost used to calculate tree alignment [3]')
    parser.add_argument('--n-genes1', metavar='<INT>', type=int, default=2000,
                        help='number of highly variable genes in data1 [2000]')
    parser.add_argument('--n-genes2', metavar='<INT>', type=int, default=2000,
                        help='number of highly variable genes in data2 [2000]')
    parser.add_argument('--local-align', action='store_true',
                        help='calculate dynamic time warping on local ailgnment [off]')

    args = parser.parse_args()

    dir_cwd = os.getcwd()

    if not os.path.isfile(args.data1):
        print('{} does not exit.'.format(args.data1))
        print('Please run pre_capital.py.')
        sys.exit()

    if not os.path.isfile(args.data2):
        print('{} does not exit.'.format(args.data2))
        print('Please run pre_capital.py.')
        sys.exit()
    
    dir_aligned_data = os.path.join(dir_cwd, "aligned_data")

    if not os.path.isdir(dir_aligned_data):
        print('Directory "aligned_data" not found.')
        os.makedirs(dir_aligned_data, exist_ok=True)
        print('Directory "aligned_data" is created.')

    preprocess = main.Preprocessing()
    data1 = preprocess.preprocess(args.data1, args.root1)
    data2 = preprocess.preprocess(args.data2, args.root2)
    
    comparison = main.Comparison(data1, data2)
    calculated_data =  comparison.compareall(cost=args.gapcost, N_1=args.n_genes1, N_2=args.n_genes2)

    print("Computing dynamic time warping for each gene.\n")

    with open(args.genes) as f:
        genes = [s.strip() for s in f.readlines()]

        for gene in tqdm(genes, desc='Progress'):
            data1_foldername = os.path.splitext(os.path.basename(args.data1))[0]
            data2_foldername = os.path.splitext(os.path.basename(args.data2))[0]
            
            if not gene in data1.rawdata_fullgene.var_names:
                print("{} does not exist in {}.".format(gene, data1_foldername))
                continue
            
            if not gene in data2.rawdata_fullgene.var_names:
                print("{} does not exist in {}.".format(gene, data2_foldername))
                continue                

            dtw = main.DynamicTimeWarping()
            results = dtw.dpt_dtw(data1, data2, calculated_data.alignedtree, gene, localalign=args.local_align)

            foldername = gene + "_" + data1_foldername + "_" + data2_foldername
            dir_folder = os.path.join(dir_aligned_data, foldername)
            count = itertools.count(1)

            while os.path.isdir(dir_folder):
                dir_folder = os.path.join(dir_aligned_data, "{0}_{1:02d}".format(foldername, next(count)))
            
            os.makedirs(dir_folder)
            
            dir_tree_folder = os.path.join(dir_folder,"tree_alignment")
            os.makedirs(dir_tree_folder)

            nx.readwrite.gexf.write_gexf(calculated_data.alignedtree,"{}/aligned_tree.gexf".format(dir_tree_folder))
            calculated_data.treedistance.to_csv("{}/tree_distance.csv".format(dir_tree_folder))
            calculated_data.forestdistance.to_csv("{}/forest_distance.csv".format(dir_tree_folder))
            calculated_data.cluster_centroid1.to_csv("{}/cluster_centroid1.csv".format(dir_tree_folder))
            calculated_data.cluster_centroid2.to_csv("{}/cluster_centroid2.csv".format(dir_tree_folder))
            calculated_data.tracetree.to_csv("{}/trace_tree.csv".format(dir_tree_folder))
            nx.readwrite.gexf.write_gexf(data1.tree,"{}/tree1.gexf".format(dir_tree_folder))
            nx.readwrite.gexf.write_gexf(data2.tree,"{}/tree2.gexf".format(dir_tree_folder))
            calculated_data.traceforest.to_csv("{}/trace_forest.csv".format(dir_tree_folder))

            with open("{}/alignment_cost.txt".format(dir_tree_folder), mode='w') as f:
                f.write("Distance per cluster: {:.3f}\n".format(calculated_data.alignmentcost))
                f.write("Number of genes used to caululate cost of the tree alignment: {}\n".format(calculated_data.num_gene))

            count = itertools.count(1)
            dir_alignment = os.path.join(dir_folder,"alignment{:03d}".format(next(count)))

            for result in results:
                while os.path.isdir(dir_alignment):
                    dir_alignment = os.path.join(dir_folder,"alignment{:03d}".format(next(count)))
                
                os.makedirs(dir_alignment)
                
                genename = result[0]
                dtw_cluster_list = result[1] 
                ordered_cells1 = result[2] 
                ordered_cells2 = result[3] 
                path = result[4]

                ls = [[genename], ['filtered_{}.h5ad'.format(data1_foldername)], ['filtered_{}.h5ad'.format(data2_foldername)]]

                with open('{}/dtwdata.csv'.format(dir_alignment), 'w') as f:
                    writer = csv.writer(f, lineterminator="\n") 
                    writer.writerows(ls)
                
                with open('{}/dtwdata_cluster.csv'.format(dir_alignment), 'w') as f:
                    writer = csv.writer(f, lineterminator="\n") 
                    writer.writerows(dtw_cluster_list)
                
                with open('{}/dtwdata_path.csv'.format(dir_alignment), 'w') as f:
                    writer = csv.writer(f, lineterminator="\n") 
                    writer.writerows(path)
                
                ordered_cells1.write('{}/filtered_{}.h5ad'.format(dir_alignment, data1_foldername))
                ordered_cells2.write('{}/filtered_{}.h5ad'.format(dir_alignment, data2_foldername))
            
    print("\nCAPITAL completed.")
