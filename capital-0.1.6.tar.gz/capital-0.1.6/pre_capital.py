#!/usr/bin/env python

import main
import argparse
import sys
import os
import itertools
import scanpy as sc

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage='./pre_capital.py [option]* <data>',
        description='pre_capital.py ver. 0.1.6\n\nRequired packages: leidenalg, matplotlib, networkx>=2.4, numpy, pandas, scanpy, scikit-learn, scipy and tslearn.\n\nThis script is used to preprocess raw data of scRNA-seq gene expression for each experiment.'
    )
    parser.add_argument('data', metavar='data <STR>', type=str,
                        help='path to the raw [TXT|CSV|H5AD] data of scRNA-seq gene expression profile')
    parser.add_argument('-t', '--transpose', action='store_true',
                        help='transpose the data [off]')    
    parser.add_argument('--min-genes', metavar='<INT>', type=int, default=200,
                        help='minimum number of genes expressed to keep [200]')
    parser.add_argument('--min-cells', metavar='<INT>', type=int, default=3,
                        help='minimum number of cells expressed to keep [3]')
    parser.add_argument('-g', '--top-n-genes', metavar='<INT>', type=int, default=2000,
                        help='number of highly variable genes to keep [1000]')
    parser.add_argument('-k', '--neighbors', metavar='<INT>', type=int, default=10,
                        help='size k of local neighborhood used to compute a k-nearest neighbor graph [10]')
    parser.add_argument('--no-save', action='store_false',
                        help='results are not saved [on: saved in ./processed_data]')
    parser.add_argument('-n','--name', metavar='<STR>', type=str, default=None,
                        help='save data as <name>.h5ad and umap_<name>.pdf')
    parser.add_argument('--save-fig', action='store_true',
                        help='save a UMAP PDF figure in ./figures [off]')
 
    args = parser.parse_args()

    preprocess = main.Preprocessing()
    adata = preprocess.read_file(args.data, transpose=args.transpose)
    adata_preprocessed = preprocess.preprocessing_rawdata(adata,
        Min_Genes=args.min_genes, Min_Cells=args.min_cells, 
        n_Top_genes=args.top_n_genes, K=args.neighbors)
    
    if args.save_fig:
        if args.name != None:
            save_name = "_" + args.name

        else:
            save_name = "_" + os.path.splitext(os.path.basename(args.data))[0]
        
        sc.pl.umap(adata_preprocessed, color=["leiden"], save=save_name)
    
    else:
        sc.pl.umap(adata_preprocessed, color=["leiden"], return_fig=True)

    if args.no_save: 
        dir_name = os.getcwd()
        dir_file = dir_name + "/processed_data"

        if not os.path.isdir(dir_file):
            print('\nDirectory "processed_data" not found.')
            print('Directory "processed_data" is created.\n')
            os.makedirs(dir_file, exist_ok=True)

        if args.name != None:
            filename = args.name + ".h5ad"
            datafile = os.path.join(dir_file, filename)
        
        elif args.name == None:
            filename = os.path.splitext(os.path.basename(args.data))[0] + ".h5ad"
            datafile = os.path.join(dir_file, filename)

        # save results of preprocess as AnnData
        if not os.path.isfile(datafile):
            preprocess.writing_adata(adata_preprocessed, datafile)
            print('Preprocessed data are saved in ./processed_data as "{}."'.format(filename))
        
        elif os.path.isfile(datafile):
            count = itertools.count(1)
            filename = os.path.splitext(os.path.basename(datafile))[0]

            while os.path.isfile(datafile):
                i = next(count)
                datafile = os.path.join(dir_file,"{0}({1:02d}).h5ad".format(filename, i))
            
            preprocess.writing_adata(adata_preprocessed,datafile)
            print('Preprocessed data are saved in ./processed_data as "{0}({1:02d}).h5ad."\n'.format(filename, i))
        
    print('Preprocess completed.')              
