import networkx as nx
import sys
import os
from contextlib import redirect_stdout
import matplotlib.pyplot as plt
import scanpy as sc
import numpy as np
import pandas as pd
import itertools
from scipy.spatial import distance
from sklearn.neighbors import DistanceMetric
from collections import deque
from networkx.drawing.nx_agraph import write_dot, graphviz_layout
from tslearn.metrics import dtw_path
from scipy import stats
import math

class Preprocessing:
    def __init__(self):
        pass
    
    def read_file(self, filename, transpose = False):
        name,filetype = os.path.splitext(filename)
        
        if filetype ==  ".txt":
            adata = sc.read_text(filename)
        if filetype == ".csv":
            adata = sc.read_csv(filename)
        if filetype == ".h5ad":
            adata = sc.read(filename)
            
        if transpose:
            adata = adata.transpose()
        return adata

    def preprocessing_rawdata(self, adata, Min_Genes = 200, Min_Cells = 3, Min_Mean = 0.0125, Max_Mean = 3, Min_Disp = 0.5, n_Top_genes = 1000,K = 10):
        sc.pp.filter_cells(adata, min_genes = Min_Genes)
        sc.pp.filter_genes(adata, min_cells = Min_Cells)
        sc.pp.normalize_total(adata, exclude_highly_expressed= True)
        sc.pp.log1p(adata)
        sc.pp.highly_variable_genes(adata, min_mean = Min_Mean, max_mean = Max_Mean, min_disp = Min_Disp,n_top_genes= n_Top_genes)
        adata_cell_filtered = adata.copy()
        adata = adata[:, adata.var['highly_variable']]
        sc.tl.pca(adata)
        sc.pp.neighbors(adata, n_neighbors = K)
        sc.tl.umap(adata)
        sc.tl.leiden(adata)
        sc.tl.paga(adata, groups='leiden')

        adata_cell_filtered.obs['leiden'] = adata.obs['leiden']
        adata_cell_filtered.uns = adata.uns
        adata_cell_filtered.obsm = adata.obsm
        
        return adata_cell_filtered
    
    def writing_adata(self,adata, results_file):
        adata.write(results_file)
        
    # get source node of tree 
    # calcurating variance of gene expression level and set node which has max variance as source node 
    def calculate_source_node(self, rawdata,threshold):
        
        cluster_centroid = self.calculate_cluster_centroid(rawdata)
        cluster_centroid = cluster_centroid.loc[:,(cluster_centroid.sum(axis = 0) != 0)]
        cor, pval = stats.spearmanr(cluster_centroid)
        gene_adjacency_matrix = np.where(abs(cor) > threshold,True,False)
        scEnergy = []
        for i in range(len(cluster_centroid.index)):
            tmp = 0
            for j in range(len(cluster_centroid.columns)):
                if cluster_centroid.iloc[i,j] != 0:
                    tmp += -cluster_centroid.iloc[i,j]*math.log(cluster_centroid.iloc[i,j]/cluster_centroid.iloc[i,:][gene_adjacency_matrix[j]].sum())
            scEnergy.append(tmp)
        sourcenode = cluster_centroid.index[scEnergy.index(max(scEnergy))]
        
        return sourcenode
    

    # cluster_centroid: pd.DataFrame
    # index is cluster name, columns is gene name, X is gene expression level
    def calculate_cluster_centroid(self, rawdata):
        cluster_centroid_data = np.empty((0, rawdata.n_vars))
        clustername = rawdata.obs['leiden'].unique().tolist()

        for i in clustername:
            a_cluster_data = rawdata[rawdata.obs['leiden'] == "{}".format(i)].to_df()
            a_cluster_median = a_cluster_data.median(axis=0).values
            cluster_centroid_data = np.vstack((cluster_centroid_data,a_cluster_median))
        cluster_centroid = pd.DataFrame(cluster_centroid_data, index = clustername, columns = rawdata.var_names)

        return cluster_centroid
    
    
    def convert_to_tree(self, rawdata, sourcenode):
        Adjecancy_matrix = np.array(rawdata.uns['paga']["connectivities_tree"].todense())
        #Adjecancy_matrix = np.array(rawdata.uns['paga']["connectivities"].todense())
        G = nx.from_numpy_matrix(Adjecancy_matrix,create_using=nx.Graph())
        
        # get names of cluster from adata.uns['paga']['groups'] as string
        groups_key = rawdata.uns['paga']['groups']
        groups_names = rawdata.obs[groups_key].cat.categories


        # relabel nodes name as names set in adata.obs of adata.uns['paga']['groups']
        G = nx.relabel_nodes(G, dict(zip(G, groups_names)))
        
        
        T = nx.minimum_spanning_tree(G)
        sorted(T.edges(data=True))
        tree = nx.dfs_tree(T,sourcenode)
        
        return tree
    
    
    
    def set_postorder_successors(self, tree, sourcenode):
        postorder = list(nx.dfs_postorder_nodes(tree, source = sourcenode)) 
        postorder = [str(i) for i in postorder]
        #print(tree.node)###DEBUG
        successors = dict(zip(map(str,list(tree.nodes)),[list(tree.successors(i)) for i in tree]))
        
        return postorder, successors
    
    
    
    # combining methods above
    def preprocess(self, filename, source_cluster = None):
        
        rawdata_fullgene = self.read_file(filename)
        print(rawdata_fullgene)
        print("\n")

        rawdata = rawdata_fullgene[:, rawdata_fullgene.var['highly_variable']].copy()
        
        if source_cluster:
            sourcenode = source_cluster
        elif source_cluster == None:
            sourcenode = self.calculate_source_node(rawdata, threshold = 0.5)

        tree = self.convert_to_tree(rawdata, sourcenode)
        postorder, successors = self.set_postorder_successors(tree, sourcenode)
         
        data = Data(filename, rawdata_fullgene,rawdata,tree, postorder, successors)

        return data

# contain frequently used data
class Data:
    def __init__(self, filename, rawdata_fullgene,rawdata, tree ,postorder, successors):
        self.__filename = filename
        self.__rawdata_fullgene = rawdata_fullgene
        self.__rawdata = rawdata
        self.__tree = tree
        self.__postorder = postorder
        self.__successors = successors
        
        
    @property
    def filename(self):
        return self.__filename
    
    @property
    def rawdata(self):
        return self.__rawdata
    
    @property
    def rawdata_fullgene(self):
        return self.__rawdata_fullgene
    
            
    @property    
    def tree(self):
        return self.__tree

        
    @property    
    def postorder(self):
        return self.__postorder

    
    @property
    def successors(self):
        return self.__successors

class CalculatedData:
    def __init__(self,data1,data2,filtered_data1, filtered_data2, cluster_centroid1, cluster_centroid2, forestdistance, treedistance, traceforest, tracetree, alignedtree, alignmentcost, num_gene):
        self.__data1 = data1
        self.__data2 = data2
        self.__filtered_data1 = filtered_data1
        self.__filtered_data2 = filtered_data2
        self.__cluster_centroid1 = cluster_centroid1
        self.__cluster_centroid2 = cluster_centroid2
        self.__forestdistance = forestdistance
        self.__treedistance = treedistance
        self.__traceforest = traceforest
        self.__tracetree = tracetree
        self.__alignedtree = alignedtree
        self.__alignmentcost = alignmentcost
        self.__num_gene = num_gene
    # has to be a better way to do this below 
    # check descriptors and sort below 
    @property
    def forestdistance(self):
        return self.__forestdistance
        
    @property
    def treedistance(self):
        return self.__treedistance

    @property
    def traceforest(self):
        return self.__traceforest

    @property
    def tracetree(self):
        return self.__tracetree
    
    @property
    def filtered_data1(self):
        return self.__filtered_data1

    @property
    def filtered_data2(self):
        return self.__filtered_data2
    
    @property    
    def cluster_centroid1(self):
        return self.__cluster_centroid1
    
    @property    
    def cluster_centroid2(self):
        return self.__cluster_centroid2
    @property    
    def alignedtree(self):
        return self.__alignedtree
    @property    
    def alignmentcost(self):
        return self.__alignmentcost

    @property    
    def num_gene(self):
        return self.__num_gene

class Comparison:        
    def __init__(self,data1,data2):
        # get combination of children
        # D(F1[i],F2[j]) is stored in forestdistance.loc[i,j]
        # D(F1[i1,i2],F2[j]) is stored in forestdistance.loc["(i1,i2)",j]
        # D({T1[i]},F2[j]) is stored in forestdistance.loc["(i,)", j]
        forest1_combinations = []
        for child in data1.successors.values():
            for k in range(1,len(child)):
                children = list(itertools.combinations(child,k))
                forest1_combinations.extend(children)
                
        forest2_combinations = []
        for child in data2.successors.values():
            for k in range(1,len(child)):
                children = list(itertools.combinations(child,k))
                forest2_combinations.extend(children)
        
        forest1 = [i for i in list(data1.tree.nodes)] + forest1_combinations + ["#"] 
        forest2 = [j for j in list(data2.tree.nodes)] + forest2_combinations + ["#"]
        forest1 = list(map(str,forest1))
        forest2 = list(map(str,forest2))

        forest = pd.DataFrame(index = forest1,columns = forest2)
        forest.loc["#","#"] = 0
        
        tree = pd.DataFrame(index = list(map(str,list(data1.tree)))+ ["#"] ,columns = list(map(str,list(data2.tree)))+ ["#"])
        tree.loc["#","#"] = 0
        
        self.__forestdistance = forest
        self.__traceforest = pd.DataFrame(index = forest1,columns = forest2)
        self.__treedistance = tree
        self.__tracetree = pd.DataFrame(index = list(map(str,list(data1.tree)))+ ["#"] ,columns = list(map(str,list(data2.tree)))+ ["#"])
        self.__data1 = data1
        self.__data2 = data2
        
    @property
    def forestdistance(self):
        return self.__forestdistance
        
    @property
    def traceforest(self):
        return self.__traceforest
    @property
    def tracetree(self):
        return self.__tracetree
    
    @property
    def treedistance(self):
        return self.__treedistance
    
    

    def sort_data(self,N_1 = None, N_2 = None):
        
        if N_1 != None:
            adata1 = self.__data1.rawdata_fullgene
            sc.pp.highly_variable_genes(adata1, n_top_genes = N_1)
            adata1 = adata1[:,adata1.var["highly_variable"]]
        elif N_1 == None:
            adata1 = self.__data1.rawdata

        if N_2 != None:    
            adata2 = self.__data2.rawdata_fullgene
            sc.pp.highly_variable_genes(adata2, n_top_genes = N_2)
            adata2 = adata2[:,adata2.var["highly_variable"]]
        elif N_2 == None:
            adata2 = self.__data2.rawdata     

        s1 = set(adata1.var.index)
        s2 = set(adata2.var.index)

        if len(s1.intersection(s2)) < 2:
            print("{} highly vairable genes of intersection of data1 and data2 is not enough to calculate cost of tree alignment\n")
            print("input --n-genes1 and --n-genes2 \n")

        adata1 = adata1[:,adata1.var.index.isin(s1.intersection(s2))]
        adata2 = adata2[:,adata2.var.index.isin(s1.intersection(s2))]

        print("{} genes are used to calculate cost of tree alignment.\n".format(len(s1.intersection(s2))))
    
        adata = adata1.concatenate(adata2)
        filtered_data1 = self.__data1.rawdata_fullgene[:, adata.var_names].copy()
        filtered_data2 = self.__data2.rawdata_fullgene[:, adata.var_names].copy()
            
        
        return filtered_data1, filtered_data2, len(s1.intersection(s2))
        
        
    # cluster_centroid: pd.DataFrame
    # index is cluster name, columns is gene name, X is gene expression level
    def calculate_cluster_centroid(self,filtered_data):
        cluster_centroid_data = np.empty((0, filtered_data.n_vars))
        clustername = filtered_data.obs['leiden'].unique().tolist()

        for i in clustername:
            a_cluster_data = filtered_data[filtered_data.obs['leiden'] == "{}".format(i)].to_df()
            a_cluster_median = a_cluster_data.median(axis=0).values
            cluster_centroid_data = np.vstack((cluster_centroid_data,a_cluster_median))
        cluster_centroid = pd.DataFrame(cluster_centroid_data, index = clustername, columns = filtered_data.var_names)

        return cluster_centroid



    # return length of i's children and tuple of children  
    def get_successors(self,data,i):
        size = len(data.successors[i])
        successor = tuple([k for k in data.successors[i]])
        if len(successor) == 0:
            successor = ("#")

        return size, successor
    
    def setF(self, i, j, distance):
        if isinstance(i,tuple):
            if len(i) == 0:
                i = "#"
            i = str(i)
            
        if isinstance(j,tuple):
            if len(j) == 0:
                j = "#"
            j = str(j)
            
        if not i in self.__forestdistance.index:
            print("error: {} does not exist in forestdistance index".format(i))
            
        if not j in self.__forestdistance.columns:
            print("error: {} does not exist in forestdistance columns".format(j))
        
        self.__forestdistance.loc[i,j] = distance
    
    def settraceF(self, i, j, trace):
        if isinstance(i,tuple):
            if len(i) == 0:
                i = "#"
            i = str(i)
            
        if isinstance(j,tuple):
            if len(j) == 0:
                j = "#"
            j = str(j)
        if not i in self.__traceforest.index:
            print(i)
            print("error: {} does not exist in traceforest index".format(i))
            
        if not j in self.__traceforest.columns:
            print(j)
            print("error: {} does not exist in traceforest columns".format(j))


        
        self.__traceforest.loc[i,j] = trace 
    
    def settraceT(self, i, j, trace):
        if isinstance(i,tuple):
            if len(i) == 0:
                i = "#"
        i = str(i)
            
        if isinstance(j,tuple):
            if len(j) == 0:
                j = "#"
        j = str(j)
        
        if not i in self.__tracetree.index:
            print(i)
            print("error: {} does not exist in tracetree index".format(i))
            
        if not j in self.__tracetree.columns:
            print(j)
            print("error: {} does not exist in tracetree columns".format(j))
        
        
        
        self.__tracetree.loc[i,j] = trace
    
    def setT(self, i, j, distance):
        if isinstance(i,tuple):
            if len(i) == 0:
                i = "#"
        i = str(i)
            
        if isinstance(j,tuple):
            if len(j) == 0:
                j = "#"
        j = str(j)

        if not i in self.__treedistance.index:
            print("error: {} does not exist in treedistance index".format(i))
            
        if not j in self.__treedistance.columns:
            print("error: {} does not exist in treedistance columns".format(j))
            
        self.__treedistance.loc[i,j] = distance
    
    def getF(self, i, j, parent1 = "Nan", parent2 = "Nan"):
        if isinstance(i,tuple):
            if len(i) == 0:
                i = "#"
        i = str(i)
        
        if isinstance(j,tuple):
            if len(j) == 0:
                j = "#"
        j = str(j)            

        if not i in self.__forestdistance.index:
            i = str(parent1)

        if not j in self.__forestdistance.columns:
            j = str(parent2)

        F = self.__forestdistance.loc[i,j]
        
        return F
    
    def getT(self, i, j):            
        i = str(i)
        j = str(j)
        
        if not i in self.__treedistance.index:
            print("error: TreeDistance index called does not exist ")
            
        if not j in self.__treedistance.columns:
            print("error: TreeDistance columns called does not exist")
        
        T = self.__treedistance.loc[i,j]
        
        return T

    def set_initial_condition(self, cost):
        COST = cost

        for i in self.__data1.postorder:
            size, successors = self.get_successors(self.__data1,i)
            if size == 1:
                # D(F1[i],θ) = Σ D(T1[ik],θ) 
                self.setF(i,"#",self.getT(successors[0],"#"))
                self.setT(i,"#",self.getF(i,"#") + COST)
            else:
                # D(F1[i],θ) = Σ D(T1[ik],θ) 
                tmp = 0
                for ichild in successors:
                    tmp += self.getT(ichild,"#")
                self.setF(i,"#",tmp)

                # D({T1[ip],...,T1[iq]},θ) = D(T1[ip],θ) + ... + D(T1[iq],θ)
                for k in range(1,size):
                    children = list(itertools.combinations(successors,k))

                    for ichild in children:
                        tmp = 0
                        for k in ichild:
                            tmp += self.getT(k,"#")
                        self.setF(ichild,"#",tmp)
                self.setT(i,"#",self.getF(i,"#") + COST)


        for j in self.__data2.postorder:
            size, successors = self.get_successors(self.__data2,j)
            if size == 1:
                self.setF("#",j, self.getT("#",successors[0]))
                self.setT("#",j, self.getF("#",j) + COST)
            else:
                tmp = 0
                for jchild in successors:
                    tmp += self.getT("#",jchild)
                self.setF("#",j,tmp)

                for k in range(1,size):
                    children = list(itertools.combinations(successors,k))

                    for jchild in children:
                        tmp = 0
                        for k in jchild:
                            tmp += self.getT("#",k)
                        self.setF("#",jchild,tmp)
                self.setT("#",j,self.getF("#",j) + COST)
       

    def cal1(self, A, B):
        if not isinstance(A,tuple):
            _, A = self.get_successors(self.__data1,A)
        
        if not isinstance(B,tuple):
            _, B = self.get_successors(self.__data2,B)


        mintemp = 1111
        trace = "Nan"
        temp = 0
        
        for k in A:
            for l in B:
                Asub = tuple([i for i in A if not i in k])
                Bsub = tuple([j for j in B if not j in l])
                
                temp = self.getF(Asub,Bsub) + self.getT(k,l)
                if mintemp > temp:
                    mintemp = temp
                    if Bsub == ():
                        Bsub = "#"
                    if l == ():
                        l = "#"
                    if Asub == ():
                        Asub = "#"
                    if k == ():
                        k = "#"
                    trace = [1,[Asub,Bsub],[k,l]]
                        
        return mintemp, trace
    
    def cal2(self, A, B, cost):
        COST = cost
        parentA = "Nan"
        parentB = "Nan"


        if not isinstance(A,tuple):
            parentA = A
            _, A = self.get_successors(self.__data1,A)
        
        if not isinstance(B,tuple):
            parentB = B
            _, B = self.get_successors(self.__data2,B)


        Bprime = [()]
        for m in range(1,len(B)+1):
            for Bp in list(itertools.combinations(B,m)):
                Bprime.extend([Bp])
        
        mintemp = 2222
        trace = "Nan"
        temp = 0

        for k in A:
            for Bp in Bprime:
                Asub = tuple([i for i in A if not i in k])
                Bsub = tuple([j for j in B if not j in Bp])
                
                if k == "#":
                    temp = self.getF(Asub,Bsub, parent2 = parentB) + self.getF("#",Bp, parent2 = parentB)
                else:
                    temp = self.getF(Asub,Bsub, parent2 = parentB) + self.getF(k,Bp, parent2 = parentB) + COST
                
                if mintemp > temp:
                    mintemp = temp
                    if Bsub == ():
                        Bsub = "#"
                    if Bp == ():
                        Bp = "#"
                    if Asub == ():
                        Asub = "#"
                    if k == ():
                        k = "#"
                    if not "{}".format(Bsub) in self.__forestdistance.columns:
                        Bsub = parentB
                    if not "{}".format(Bp) in self.__forestdistance.columns:
                        Bp = parentB
                    
                    trace = [2,[[Asub,Bsub],[k,Bp]],(k,"#")]
                
        return mintemp, trace

    # min D(A-Aprime,B-{T2[jq]}) + D(Aprime,F2[jq]) + cost 
    def cal3(self, A, B, cost):
        COST = cost
        parentA = "Nan"
        parentB = "Nan"

        if not isinstance(A,tuple):
            parentA = A 
            _, A = self.get_successors(self.__data1,A)
        
        if not isinstance(B,tuple):
            parentB = B
            _, B = self.get_successors(self.__data2,B)

        Aprime = [()]
        for m in range(1,len(A)+1):
            for Ap in list(itertools.combinations(A,m)):
                Aprime.extend([Ap])

        mintemp = 3333
        trace = "Nan"
        temp = 0

        for l in B:
            for Ap in Aprime:
                
                Asub = tuple([i for i in A if not i in Ap])
                Bsub = tuple([j for j in B if not j in l])
                temp = self.getF(Asub, Bsub, parent1 = parentA) + self.getF(Ap, l, parent1 = parentA) + COST
                
                if mintemp > temp:
                    mintemp = temp
                    if Bsub == ():
                        Bsub = "#"
                    if l == ():
                        l = "#"
                    if Asub == ():
                        Asub = "#"
                    if Ap == ():
                        Ap = "#"
                        
                    if not "{}".format(Asub) in self.__forestdistance.index:
                        Asub = parentA
                    if not "{}".format(Ap) in self.__forestdistance.index:
                        Ap = parentA
                    trace = [3,[[Asub,Bsub],[Ap,l]],("#",l)]
                
        return mintemp, trace
     
    # trace is a list that has 3 pairs like [a,(b),(c)]
    # a is a record that show which calculation was done
    # (b) is a pair or 2 pairs that goes to the search in traceforest for the next traceback
    # (c) is a pair that goes to stack or foreststack
    def calculateForest(self, A, B,cost):
        COST = cost
        min1, trace1 = self.cal1(A,B)
        min2, trace2 = self.cal2(A,B,COST)
        min3, trace3 = self.cal3(A,B,COST)
        
        forestdistance = np.array([min1,min2,min3]).min()
        trace = [trace1,trace2,trace3][np.array([min1,min2,min3]).argmin()]
        
        return forestdistance, trace
    
    # trace is a list that has 3 pairs like [(a),(b),(c)] 
    # (a) is a record that show which calculation was done
    # (b) is a pair of the match result for D(T[i],T[j])
    # (c) is a pair that goes to the stack 
    def calculateTree(self, i, j, mincost):
        MINCOST = mincost
        _, successor1 = self.get_successors(self.__data1,i)
        _, successor2 = self.get_successors(self.__data2,j)
        
        distancelist = []
        for l in successor2:
            distancelist.append([self.getT("#",j) + self.getT(i,l) - self.getT("#",l),[0,("#",j),(i,l)]])
        for k in successor1:
            distancelist.append([self.getT(i,"#") + self.getT(k,j) - self.getT(k,"#"),[0,(i,"#"),(k,j)]])
            
        distancelist.append([self.getF(i,j) + MINCOST,[1,(i,j),(i,j)]])
        
        array = np.array(distancelist)
        
        treedistance = array[:,0].min()
        trace = array[array[:,0].argmin(),1]
        
        return treedistance, trace
            
    def dp(self,cluster_centroid1, cluster_centroid2, cost):
        COST = cost
        for i in self.__data1.postorder:
            for j in self.__data2.postorder:
                df = pd.DataFrame({"A":cluster_centroid1.loc[i], "B":cluster_centroid2.loc[j]})
                mincost = 1 - df.corr(method="spearman").iloc[0,1]
                
                _, successor1 = self.get_successors(self.__data1,i)
                _, successor2 = self.get_successors(self.__data2,j)
                
                Alist = []
                
                if len(successor1) == 1:
                    pass
                else:
                    for m in range(1,len(successor1)):
                        for l in list(itertools.combinations(successor1,m)):
                            Alist.extend([l])
                
                Alist.extend([i])

                if len(successor2) == 1:
                    pass
                else:    
                    for m in range(1,len(successor2)):
                        for B in list(itertools.combinations(successor2,m)):
                            for A in Alist:
                                fdistance, ftrace = self.calculateForest(A,B,COST)
                                self.setF(A,B,fdistance)
                                self.settraceF(A,B,ftrace)

                for A in Alist:
                    fdistance, ftrace = self.calculateForest(A,j,COST)
                    self.setF(A,j,fdistance)
                    self.settraceF(A,j,ftrace)
                
                tdistance, ttrace = self.calculateTree(i,j,mincost)
                self.setT(i,j,tdistance)
                self.settraceT(i,j,ttrace)
                              
    def traceback(self):
        G = nx.DiGraph()
        G.add_node("tempnode")
        parent = "tempnode"
        
        stack = deque()
        stack.append((self.__data1.postorder[-1], self.__data2.postorder[-1],parent))
        
        while len(stack) != 0:
            i,j,parent = stack.pop()
            if i == "#" and j == "#":
                continue

            elif i == "#":
                if j != "#":
                    H = nx.dfs_tree(self.__data2.tree,j)
                    G = nx.compose(G,H)
                    G.add_edge(parent,j)
                    G = nx.relabel_nodes(G,dict(zip(list(H.nodes),[("#",k) for k in H.nodes])))
                continue

            elif j == "#":
                if i != "#":
                    H = nx.dfs_tree(self.__data1.tree,i)
                    G = nx.compose(G,H)
                    G.add_edge(parent,i)
                    G = nx.relabel_nodes(G,dict(zip(list(H.nodes),[(k,"#") for k in H.nodes])))
                continue
            

            elif  i != "#" and j != "#":
                tree_result = self.__tracetree.loc[i,j]
                forest_result = self.__traceforest.loc[i,j]
                G.add_node(tree_result[1])
                G.add_edge(parent,tree_result[1])

                if tree_result[0] == 0:
                    stack.append([tree_result[2][0],tree_result[2][1],tree_result[1]])

                elif tree_result[0] == 1:
                    foreststack = deque()
                    foreststack.append([i,j,(i,j)])


                    while len(foreststack) != 0:
                        i_f,j_f,p_f = foreststack.pop()

                        if i_f == "#" and j_f == "#":
                            continue

                        elif i_f == "#":
                            if j_f != "#":
                                for j_tmp in j_f:
                                    H = nx.dfs_tree(self.__data2.tree,j_tmp)
                                    G = nx.compose(G,H)
                                    G.add_edge(p_f,j_tmp)
                                    G = nx.relabel_nodes(G,dict(zip(list(H.nodes),[("#",k) for k in H.nodes])))

                        elif j_f == "#":
                            if i_f != "#":
                                for i_tmp in i_f:
                                    H = nx.dfs_tree(self.__data1.tree,i_tmp)
                                    G = nx.compose(G,H)
                                    G.add_edge(p_f,i_tmp)
                                    G = nx.relabel_nodes(G,dict(zip(list(H.nodes),[(k,"#") for k in H.nodes])))


                        elif i_f != "#" and j_f != "#":
                            i_f = "{}".format(i_f)
                            j_f = "{}".format(j_f)

                            forest_result = self.__traceforest.loc[i_f,j_f]
                            if forest_result[0] == 1:
                                stack.append([forest_result[2][0],forest_result[2][1],p_f])
                                foreststack.append([forest_result[1][0],forest_result[1][1],p_f])

                            elif forest_result[0] == 2:
                                foreststack.append([forest_result[1][0][0],forest_result[1][0][1],p_f])
                                # childがいない者同士とかで入れると二重に結果に記録してしまうのでムリクリ解決してる　なんかあれば修正
                                if forest_result[1][1][1] != "#":
                                    G.add_node(forest_result[2])
                                    G.add_edge(p_f,forest_result[2])
                                    foreststack.append([forest_result[1][1][0],forest_result[1][1][1],forest_result[2]])
                                
                                elif forest_result[1][1][1] == "#":
                                    H = nx.dfs_tree(self.__data1.tree,forest_result[1][1][0])
                                    G = nx.compose(G,H)
                                    G.add_edge(p_f,forest_result[1][1][0])
                                    G = nx.relabel_nodes(G,dict(zip(list(H.nodes),[(k,"#") for k in H.nodes])))

                            elif forest_result[0] == 3:
                                foreststack.append([forest_result[1][0][0],forest_result[1][0][1],p_f])

                                if forest_result[1][1][0] != "#":
                                    G.add_node(forest_result[2])
                                    G.add_edge(p_f,forest_result[2])
                                    foreststack.append([forest_result[1][1][0],forest_result[1][1][1],forest_result[2]])
                                
                                elif forest_result[1][1][0] == "#":
                                    H = nx.dfs_tree(self.__data2.tree,forest_result[1][1][1])
                                    G = nx.compose(G,H)
                                    G.add_edge(p_f,forest_result[1][1][1])
                                    G = nx.relabel_nodes(G,dict(zip(list(H.nodes),[("#",k) for k in H.nodes])))
        
        G.remove_node("tempnode")
        alignmentcost = self.__treedistance.loc[self.__data1.postorder[-1], self.__data2.postorder[-1]]
        
        alignmentcost_per_cluster = alignmentcost/len(G)


        return G, alignmentcost_per_cluster

    def compareall(self,cost = 3, N_1 = None,N_2 = None):
        COST = cost
        filtered_data1, filtered_data2, num_gene = self.sort_data(N_1,N_2)
        cluster_centroid1 = self.calculate_cluster_centroid(filtered_data1)
        cluster_centroid2 = self.calculate_cluster_centroid(filtered_data2)
        self.set_initial_condition(COST)
        self.dp(cluster_centroid1,cluster_centroid2,COST)
        G, alignmentcost= self.traceback()
        
        calculated_data = CalculatedData(self.__data1, self.__data2, filtered_data1, filtered_data2, cluster_centroid1, cluster_centroid2, 
                                         self.__forestdistance, self.__treedistance, self.__traceforest, self.__tracetree, G, alignmentcost, num_gene)


        return calculated_data
    
class DynamicTimeWarping:
    def __init__(self):
        pass
    
    def dpt(self, data, cluster_list):
        
        count = 0 
        source_cluster = cluster_list[count]
        
        while not data.rawdata.obs['leiden'].isin([source_cluster]).any():
            count += 1
            source_cluster = cluster_list[count]
    
        # get  cells only in the clusters of cluster_list
        adata_dpt = data.rawdata[data.rawdata.obs['leiden'].isin(cluster_list)].copy()
        dist = DistanceMetric.get_metric('euclidean')
        distancearray = dist.pairwise(adata_dpt.X)
        distancearray = np.array(distancearray.sum(axis = 1))
        loc = np.argsort(distancearray)
        count = 0 
        while adata_dpt.obs['leiden'][np.where(loc == count)[0][0]] != source_cluster:
            count += 1

        
        # "iroot" is a cell that are the source of 
        root = np.flatnonzero(adata_dpt.obs['leiden'])[np.where(loc == count)[0][0]]
        adata_dpt.uns['iroot'] = root
    
        # process diffusion maps and dpt, calculate "dpt_pseudotime"
        sc.tl.diffmap(adata_dpt)
        sc.tl.dpt(adata_dpt)
    
        return adata_dpt
    
    # data used to do dynamic time warping are stored in file1_ordered_data, file2_ordered_data, paths
    # if nodes tha are compared are empty, data are stored as ""
    # if the opponent side of the node is empty, the data is sorted and stored, but the another node and path are stored as ""

    # 

    def applying_dtw_to_clusters(self, adata_dpt1, adata_dpt2, real_nodes1, real_nodes2,geneid):
        cells1 = adata_dpt1[adata_dpt1.obs['leiden'].isin(real_nodes1)].copy()
        cells2 = adata_dpt2[adata_dpt2.obs['leiden'].isin(real_nodes2)].copy()
        
        ordered_cells1 = cells1[cells1.obs.sort_values("dpt_pseudotime").index].copy()
        ordered_cells2 = cells2[cells2.obs.sort_values("dpt_pseudotime").index].copy()
        
        #excluding cells that have too low or too high gene expression
        gene_expression1 = pd.Series(ordered_cells1.X[:,geneid])
        max_outlier = gene_expression1.quantile(0.95)
        min_outlier = gene_expression1.quantile(0.05)
        ordered_cells1 = ordered_cells1[ordered_cells1.X[:,geneid] <= max_outlier]
        ordered_cells1 = ordered_cells1[ordered_cells1.X[:,geneid] >= min_outlier]

        gene_expression2 = pd.Series(ordered_cells2.X[:,geneid])
        max_outlier = gene_expression2.quantile(0.95)
        min_outlier = gene_expression2.quantile(0.05)
        ordered_cells2 = ordered_cells2[ordered_cells2.X[:,geneid] <= max_outlier]
        ordered_cells2 = ordered_cells2[ordered_cells2.X[:,geneid] >= min_outlier]
        
        
        path, dist = dtw_path(ordered_cells1.X[:,geneid],ordered_cells2.X[:,geneid])
        
        return ordered_cells1, ordered_cells2, path
    

    def applying_dtw_to_one_path(self, data1, data2, alignedtree, dtw_cluster_list, genename):  
            
        real_nodes1 = [nodes[0] for nodes in dtw_cluster_list if nodes[0] in data1.rawdata.obs['leiden'].values]
        real_nodes2 = [nodes[1] for nodes in dtw_cluster_list if nodes[1] in data2.rawdata.obs['leiden'].values]


        data_dpt1 = self.dpt(data1, real_nodes1)
        data_dpt2 = self.dpt(data2, real_nodes2)

        
        adata = data1.rawdata_fullgene.concatenate(data2.rawdata_fullgene)
        adata1 = data1.rawdata_fullgene[:, adata.var_names]
        adata2 = data2.rawdata_fullgene[:, adata.var_names] 
        
        adata1 = adata1[data_dpt1.obs_names].copy()
        adata1.obs['dpt_pseudotime'] = data_dpt1.obs['dpt_pseudotime']
        
        adata2 = adata2[data_dpt2.obs_names].copy()
        adata2.obs['dpt_pseudotime'] = data_dpt2.obs['dpt_pseudotime']
        
        
        geneid = adata1.var_names.get_loc(genename)
        
        ordered_cells1, ordered_cells2, path = self.applying_dtw_to_clusters(adata1, adata2, real_nodes1,real_nodes2, geneid)
        
        result_list = [genename, dtw_cluster_list ,ordered_cells1, ordered_cells2, path]
        
        return result_list
    
    def dpt_dtw(self, data1, data2, alignedtree, genename,localalign = False):
        
        # get list of pairs of clusters that is going to be applyed dtw 
        # path_dtw_list stores all list of pairs of clusters

        path_dtw_list = []
        for node in list(alignedtree.nodes):
            source_node = list(nx.topological_sort(alignedtree))[0]
    
            if len(list(alignedtree.successors(node))) == 0:
                dtw_cluster_list = nx.shortest_path(alignedtree, source = source_node, target = node)
                path_dtw_list.append(dtw_cluster_list)
        
        all_result_list = []
        
        for dtw_cluster_list in path_dtw_list:            
            if localalign:
                tmp = []
                for i in dtw_cluster_list:
                    if i[0] == "#" or i[1] == "#":
                        tmp.append(i)
                    if i[0] != "#" and i[1] != "#":
                        break
                for i in dtw_cluster_list[::-1]:
                    if i[0] == "#" or i[1] == "#":
                        tmp.append(i)
                    if i[0] != "#" and i[1] != "#":
                        break
                dtw_cluster_list = [i for i in dtw_cluster_list if not i in tmp]

            result_list = self.applying_dtw_to_one_path(data1, data2, alignedtree, dtw_cluster_list, genename)
            all_result_list.append(result_list)
            
        return all_result_list

class Drawing:
    def __init__(self):
        pass
    # show graph of results of dynamic time warping 
    # points in 1 in y axis are data from data1 and points in 2 are from data2  
    def draw_dtw_graph(self, genename, dtw_cluster_list,ordered_cells1, ordered_cells2, path,
                        data1_name=None, data2_name=None, save=False):
        
        plt.figure()
        plt.title("{} to {},{}".format(dtw_cluster_list[0],dtw_cluster_list[-1],genename))
        
        y1 = ordered_cells1.obs["dpt_pseudotime"]
        colormap = ordered_cells1.obs["leiden"].copy()
        colors = ordered_cells1.uns["leiden_colors"]
        if not type(colors) == np.ndarray:
            colors = np.array(colors)
        colormap = colormap.replace(dict(zip(ordered_cells1.obs["leiden"].cat.categories,colors)))
        plt.scatter(np.array(list(y1)),np.ones(len(y1)),color= colormap, zorder=2, label=data1_name)

        y2 = ordered_cells2.obs["dpt_pseudotime"]
        colormap = ordered_cells2.obs["leiden"].copy()
        colors = ordered_cells2.uns["leiden_colors"]
        if not type(colors) == np.ndarray:
            colors = np.array(colors)
        colormap = colormap.replace(dict(zip(ordered_cells2.obs["leiden"].cat.categories,colors)))
        plt.scatter(np.array(list(y2)),np.zeros(len(y2)), color=colormap, zorder=2, label=data2_name)

        for i, j in path:
            i = int(i)
            j = int(j)
            plt.plot((y1[i], y2[j]), (1, 0), color = 'grey', alpha = 0.5, zorder = 1)

        plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', borderaxespad=0, fontsize=18)

        plt.tick_params(labelbottom=True,
                        labelleft=False,
                        labelright=False,
                        labeltop=False)
        plt.tick_params(bottom=False,
                        left=False,
                        right=False,
                        top=False)
        plt.grid(False)

        if save:
            plt.savefig(save)
            print("dtw_graph is saved in {}.\n".format(save))
    
    def draw_gene_expression_comparison(self, genename, dtw_cluster_list, ordered_cells1,ordered_cells2, path, 
                                    data1_name = None, data2_name = None, polyfit_dimention = 6,save = False,
                                    switch_psedotime = False):
        
        plt.figure()
        plt.title("{} to {}, {}".format(dtw_cluster_list[0], dtw_cluster_list[-1],
                                       genename))
        

        geneid = ordered_cells1.var_names.get_loc(genename)

        pseudotime = []
        data1_expression_level = []
        data2_expression_level = []

        for i,j in path:
            i = int(i)
            j = int(j)
            if switch_psedotime:
                pseudotime.append(ordered_cells2.obs["dpt_pseudotime"][j])
            else:
                pseudotime.append(ordered_cells1.obs["dpt_pseudotime"][i])
            
            data1_expression_level.append(ordered_cells1.X[:,geneid][i])
            data2_expression_level.append(ordered_cells2.X[:,geneid][j])
                
        df = pd.DataFrame([pseudotime, data1_expression_level, data2_expression_level],
                         index = ["pseudotime", "expression_level1", "expression_level2"])
        df = df.T
        
        df = df.sort_values("pseudotime")

        df1 = df[["pseudotime","expression_level1"]]
        df1["qcut"] = pd.qcut(df1["pseudotime"],10,labels = False,duplicates='drop')

        df1_poly1d = pd.DataFrame([])

        for i in df1["qcut"].unique():
            df_temp = df1.groupby('qcut').get_group(i)
            max_outlier = df_temp["expression_level1"].quantile(0.75,interpolation='lower')
            min_outlier = df_temp["expression_level1"].quantile(0.25,interpolation='higher')
            df_temp = df_temp[df_temp["expression_level1"] <= max_outlier]
            df_temp = df_temp[df_temp["expression_level1"] >= min_outlier]    
            df1_poly1d = df1_poly1d.append(df_temp)

        df2 = df[["pseudotime","expression_level2"]]
        df2["qcut"] = pd.qcut(df2["pseudotime"],10,labels = False,duplicates='drop')
        df2_poly1d = pd.DataFrame([])

        for i in df2["qcut"].unique():
            df_temp = df2.groupby('qcut').get_group(i)
            max_outlier = df_temp["expression_level2"].quantile(0.75,interpolation='lower')
            min_outlier = df_temp["expression_level2"].quantile(0.25,interpolation='higher')
            df_temp = df_temp[df_temp["expression_level2"] <= max_outlier]
            df_temp = df_temp[df_temp["expression_level2"] >= min_outlier]   
            df2_poly1d = df2_poly1d.append(df_temp)


        plt.plot(df["pseudotime"], df["expression_level1"], "o", color = "tomato",alpha = 0.5)
        plt.plot(df["pseudotime"], df["expression_level2"], "o", color = "lightskyblue",alpha = 0.5)
        
        y1 = np.poly1d(np.polyfit(df1_poly1d["pseudotime"], df1_poly1d["expression_level1"], polyfit_dimention))(df1_poly1d["pseudotime"])
        y2 = np.poly1d(np.polyfit(df2_poly1d["pseudotime"], df2_poly1d["expression_level2"], polyfit_dimention))(df2_poly1d["pseudotime"])

        plt.plot(df1_poly1d["pseudotime"], y1, color="red",label = data1_name)
        plt.plot(df2_poly1d["pseudotime"], y2, color="blue",label = data2_name)            

        plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', borderaxespad=0, fontsize=12)

        if save:
            plt.savefig(save)
            print("dtw_graph is saved in {}\n".format(save))
