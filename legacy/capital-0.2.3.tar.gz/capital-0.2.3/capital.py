#!/usr/bin/env python

import argparse
import os
import sys
import warnings
from tqdm import tqdm
import itertools
import networkx as nx
import numpy as np
import pandas as pd

import main

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage='./capital.py [option]* <data1> <data2> <root1> <root2> <genes>',
        description='capital.py ver. 0.2.3\n\nRequired packages: graphtools, leidenalg, magic-impute, pygraphviz, scanpy>=1.5, scprep and tslearn.\n\n\
            This script is used to predict pseudotime trajectories for two preprocessed data and compute a trajectory alignment.\n\
            Users have to run pre_capital.py for each experiment before using this.'
    )
    parser.add_argument('data1',
                        metavar='data1 <STR>',
                        type=str,
                        help='path to the preprocessed expression H5AD data for experiment 1 generated with pre_capital.py')
    parser.add_argument('data2', metavar='data2 <STR>', type=str,
                        help='path to the preprocessed expression H5AD data for experiment 2 generated with pre_capital.py')
    parser.add_argument('root1',
                        metavar='root1 <STR>',
                        type=str,
                        help='root cluster in data1')
    parser.add_argument('root2',
                        metavar='root2 <STR>',
                        type=str,
                        help='root cluster in data2')
    parser.add_argument('genes',
                        metavar='genes <STR>',
                        type=str,
                        help='path to the file that contains gene names to be analyzed (one gene per line)')
    parser.add_argument('-M', '--method',
                        choices=["euclid", "gauss", "paga"],
                        default="euclid",
                        help='method for calculating a tree [euclid]')
    parser.add_argument('-d', '--dimension',
                        choices=["pca", "diffmap"],
                        default="pca",
                        help='dimension metric for calculating a tree [pca]')
    parser.add_argument('-c', '--gapcost',
                        metavar='<FLOAT>',
                        type=float,
                        default=1.0,
                        help='gap cost for calculating a tree alignment [1.0]')
    parser.add_argument('-m', '--n-genes1',
                        metavar='<INT>',
                        type=int,
                        default=2000,
                        help='number of highly variable genes in data1 [2000]')
    parser.add_argument('-n', '--n-genes2',
                        metavar='<INT>',
                        type=int,
                        default=2000,
                        help='number of highly variable genes in data2 [2000]')
    parser.add_argument('-t', '--tune',
                        action='store_true',
                        help='tuning mode, which affects naming of the result directory and never saves H5AD data [off]')
    parser.add_argument('--no-prune',
                        action='store_true',
                        help='disable pruning of space nodes on edges of each alignment path for dynamic time warping [off]')
    args = parser.parse_args()

    if not os.path.isfile(args.data1):
        print('ERROR: {} does not exit.'.format(args.data1))
        print('Please run pre_capital.py.')
        sys.exit()

    if not os.path.isfile(args.data2):
        print('ERROR: {} does not exit.'.format(args.data2))
        print('Please run pre_capital.py.')
        sys.exit()

    # reading genes file
    if os.path.splitext(args.genes)[1][1:] == "tsv":
        genes = pd.read_table(args.genes, header=None)[0].values.tolist()

    elif os.path.splitext(args.genes)[1][1:] == "csv":
        genes = pd.read_csv(args.genes, header=None)[0].values.tolist()

    elif os.path.splitext(args.genes)[1][1:] == "txt":
        with open(args.genes, 'r') as f:
            genes = [s.strip() for s in f.readlines()]

    else:
        print("ERROR: genes file must be text, csv or tsv.")
        sys.exit()

    dir_cwd = os.getcwd()

    # ./aligned_data_method if the tuning mode is on
    if args.tune:
        dir_aligned_data = os.path.join(
            dir_cwd, "aligned_data_{}".format(args.method))

        if not os.path.isdir(dir_aligned_data):
            print(
                'WARNING: directory "./aligned_data_{}" not found.\n'.format(args.method))
            os.mkdir(dir_aligned_data)
            print('Directory "./aligned_data_{}" is created.\n'.format(args.method))

    # ./aligned_data otherwise
    else:
        dir_aligned_data = os.path.join(dir_cwd, "aligned_data")

        if not os.path.isdir(dir_aligned_data):
            print('WARNING: directory "./aligned_data" not found.\n')
            os.mkdir(dir_aligned_data)
            print('Directory "./aligned_data" is created.\n')

    with warnings.catch_warnings():
        warnings.simplefilter('ignore', FutureWarning)
        # Preprocess each data
        preprocess = main.Preprocessing()
        data1 = preprocess.preprocess(
            args.data1,
            args.root1,
            method=args.method,
            dimension=args.dimension
        )
        data2 = preprocess.preprocess(
            args.data2,
            args.root2,
            method=args.method,
            dimension=args.dimension
        )

        # # Compare data1 with data2 by tree alignment
        comparison = main.Comparison(data1, data2)
        calculated_data = comparison.compareall(
            cost=args.gapcost,
            N_1=args.n_genes1,
            N_2=args.n_genes2
        )

    # ./aligned_data/data1_data2
    data1_dirname = os.path.splitext(os.path.basename(args.data1))[0]
    data2_dirname = os.path.splitext(os.path.basename(args.data2))[0]
    comp_dirname = "{}_{}".format(data1_dirname, data2_dirname)
    dir_comp_temp = os.path.join(dir_aligned_data, comp_dirname)

    # ./aligned_data/data1_data2/param if the tuning mode is on
    if args.tune:
        param_dirname = "r{}_r{}_c{:.2f}_m{}_n{}".format(
            args.root1, args.root2, args.gapcost, args.n_genes1, args.n_genes2)
        dir_comp = os.path.join(dir_comp_temp, param_dirname)

    # ./aligned_data/data1_data2 otherwise
    else:
        dir_comp = dir_comp_temp

    count = itertools.count(1)

    while os.path.isdir(dir_comp):
        if args.tune:
            dir_comp = os.path.join(
                dir_comp_temp, "{0}_{1:02d}".format(param_dirname, next(count)))

        else:
            dir_comp = os.path.join(
                dir_aligned_data, "{0}_{1:02d}".format(comp_dirname, next(count)))

    os.makedirs(dir_comp, exist_ok=True)

    # ./aligned_data/data1_data2/tree_alignment
    dir_tree = os.path.join(dir_comp, "tree_alignment")
    os.makedirs(dir_tree, exist_ok=True)

    draw = main.Drawing()
    draw.draw_tree(calculated_data.alignedtree,
                    "{}/aligned_tree".format(dir_tree))
    draw.draw_tree(data1.tree, "{}/tree1".format(dir_tree))
    draw.draw_tree(data2.tree, "{}/tree2".format(dir_tree))
    nx.readwrite.gexf.write_gexf(
        calculated_data.alignedtree, "{}/aligned_tree.gexf".format(dir_tree))
    nx.readwrite.gexf.write_gexf(data1.tree, "{}/tree1.gexf".format(dir_tree))
    nx.readwrite.gexf.write_gexf(data2.tree, "{}/tree2.gexf".format(dir_tree))

    np.savez_compressed("{}/calculated_data".format(dir_tree),
                        tree_distance=calculated_data.treedistance.values,
                        forest_distance=calculated_data.forestdistance.values,
                        cluster_centroid1=calculated_data.cluster_centroid1.values,
                        cluster_centroid2=calculated_data.cluster_centroid2.values,
                        trace_tree=calculated_data.tracetree.values,
                        trace_forest=calculated_data.traceforest.values
                        )

    with open("{}/alignment_cost.txt".format(dir_tree), 'w') as g:
        g.write("Distance per cluster: {:.3f}\n".format(
            calculated_data.alignmentcost))
        g.write("Number of genes used to calcurate cost of the tree alignment: {}\n".format(
            calculated_data.num_gene))

    for gene in genes[:]:
        if gene not in data1.rawdata_fullgene.var_names:
            print("WARNING: {} does not exist in {}.\n".format(
                gene, data1_dirname))
            genes.remove(gene)

        if gene not in data2.rawdata_fullgene.var_names:
            print("WARNING: {} does not exist in {}.\n".format(
                gene, data2_dirname))

            if gene in genes:
                genes.remove(gene)

    if len(genes) == 0:
        print("ERROR: genes that you selected do not exist in at least one of the data.")
        sys.exit()

    print("Computing pseudotime for each alignment path.\n")

    dtw = main.DynamicTimeWarping()
    all_adata_pairs = dtw.applying_dpt_to_all_path(
        data1, data2, calculated_data.alignedtree, no_prune=args.no_prune)

    print("Computing dynamic time warping for each gene.")

    for i, adata_pairs in enumerate(all_adata_pairs):
        # ./aligned_data/data1_data2/alignment00X
        dir_alignment = os.path.join(
            dir_comp, "alignment{:03d}".format(i))
        os.makedirs(dir_alignment, exist_ok=True)

        adata1, adata2, dtw_cluster_list = adata_pairs
        pd.DataFrame(dtw_cluster_list, columns=[data1_dirname, data2_dirname]).to_csv(
            "{}/aligned_clusters.csv".format(dir_alignment), header=True, index=False)

        if not args.tune:
            adata1.write(
                "{}/filtered_{}.h5ad".format(dir_alignment, data1_dirname), compression='gzip')
            adata2.write(
                "{}/filtered_{}.h5ad".format(dir_alignment, data2_dirname), compression='gzip')

    for gene in tqdm(genes, desc='Progress'):
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', FutureWarning)
            dtw = main.DynamicTimeWarping()
            results = dtw.applying_dtw_to_all_alignment(
                all_adata_pairs, gene)

        for i, result in enumerate(results):
            dir_alignment = os.path.join(
                dir_comp, "alignment{:03d}".format(i))

            # ./aligned_data/data1_data2/alignment00X/gene
            dir_gene = os.path.join(dir_alignment, gene)
            os.makedirs(dir_gene, exist_ok=True)

            genename = result[0]
            dtw_cluster_list = result[1]
            ordered_cells1 = result[2]
            ordered_cells2 = result[3]
            path = result[4]

            dtwdata = np.array([[genename],
                                ["filtered_{}.h5ad".format(data1_dirname)],
                                ["filtered_{}.h5ad".format(data2_dirname)]])

            # ./aligned_data/data1_data2/alignment00X/gene/alignment_data.npz
            np.savez_compressed("{}/alignment_data".format(dir_gene),
                                dtwdata=dtwdata,
                                dtwdata_cluster=np.array(dtw_cluster_list),
                                dtwdata_path=np.array(path),
                                colors1=data1.uns["leiden_colors"],
                                colors2=data2.uns["leiden_colors"],
                                ordered_cells1=ordered_cells1,
                                ordered_cells2=ordered_cells2)

    print("\nCAPITAL completed.")
