#!/usr/bin/env python

import main
import argparse
import os
import scanpy as sc
import csv

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage='./draw_capital.py [option]* <alignment>',
        description='draw_capital.py ver. 0.1.7\n\nRequired packages: leidenalg, matplotlib, networkx>=2.4, numpy, pandas, scanpy, scikit-learn, scipy and tslearn.\n\nThis script is used to show figures on dynamic time warping and/or expression dynamics for a gene in aligned_data.\nUsers have to run capital.py before using this.'
    )
    parser.add_argument('alignment', metavar='alignment <STR>', type=str,
                        help='path to the aligned data generated with capital.py (e.g. ./aligned_data/data1_data2/alignment001)')
    parser.add_argument('--data1-name', metavar='<STR>', type=str, default=None,
                        help='data1 name on the plot')
    parser.add_argument('--data2-name', metavar='<STR>', type=str, default=None,
                        help='data2 name on the plot')
    parser.add_argument('--save-dtw', metavar='<STR>', default=False,
                        help='path to the (e.g. PDF) figure on dynamic time warping')
    parser.add_argument('--save-dyn', metavar='<STR>', default=False,
                        help='path to the (e.g. PDF) figure on gene expression dynamics') 
    args = parser.parse_args()

    with open(os.path.join(args.alignment, "dtwdata_cluster.csv")) as f:
        reader = csv.reader(f) 
        cluster_list = [r for r in reader]
    
    with open(os.path.join(args.alignment, "dtwdata_path.csv")) as f:
        reader = csv.reader(f) 
        path = [r for r in reader]
    
    with open(os.path.join(args.alignment, "dtwdata.csv")) as f:
        reader = csv.reader(f) 
        ls = [r for r in reader]
        genename = ls[0][0]
        filtered_data1_file = ls[1][0]
        filtered_data2_file = ls[2][0]  

    data1_fpath = os.path.join(args.alignment, str(filtered_data1_file))
    data2_fpath = os.path.join(args.alignment, str(filtered_data2_file))
    
    data1 = sc.read(data1_fpath)
    data2 = sc.read(data2_fpath)

    draw = main.Drawing()
    draw.draw_dtw_graph(genename, cluster_list, data1, data2, path, 
                        data1_name=args.data1_name, data2_name=args.data1_name, save=args.save_dtw)

    draw.draw_gene_expression_comparison(genename, cluster_list, data1, data2, path, 
                                        data1_name=args.data1_name, data2_name=args.data1_name, save=args.save_dyn)
