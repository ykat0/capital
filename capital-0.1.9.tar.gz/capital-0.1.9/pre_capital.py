#!/usr/bin/env python

import main
import argparse
import os
import itertools
import scanpy as sc

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage='./pre_capital.py [option]* <data>',
        description='pre_capital.py ver. 0.1.9\n\nRequired packages: leidenalg, matplotlib, networkx>=2.4, numpy, pandas, scanpy, scikit-learn, scipy and tslearn.\n\nThis script is used to preprocess raw data of scRNA-seq gene expression for each experiment.'
    )
    parser.add_argument('data', metavar='data <STR>', type=str,
                        help='path to the raw [TXT|CSV|H5AD] data of scRNA-seq gene expression profile')
    parser.add_argument('-t', '--transpose', action='store_true',
                        help='transpose the data [off]')    
    parser.add_argument('--min-genes', metavar='<INT>', type=int, default=200,
                        help='minimum number of genes expressed to keep [200]')
    parser.add_argument('--min-cells', metavar='<INT>', type=int, default=3,
                        help='minimum number of cells expressed to keep [3]')
    parser.add_argument('-n', '--top-n-genes', metavar='<INT>', type=int, default=2000,
                        help='number of highly variable genes to keep [1000]')
    parser.add_argument('-k', '--neighbors', metavar='<INT>', type=int, default=10,
                        help='size k of local neighborhood used to compute a k-nearest neighbor graph [10]')
    parser.add_argument('--no-save', action='store_false',
                        help='results are not saved [on: saved in ./processed_data]')
    parser.add_argument('-f','--filename', metavar='<STR>', type=str, default=None,
                        help='save data as <filename>.h5ad and umap_<filename>.pdf')
    parser.add_argument('--save-fig', action='store_true',
                        help='save a UMAP PDF figure in ./figures [off]')
    args = parser.parse_args()
    
    preprocess = main.Preprocessing()
    adata = preprocess.read_file(args.data, transpose=args.transpose)
    adata_preprocessed = preprocess.preprocessing_rawdata(adata,
        Min_Genes=args.min_genes, Min_Cells=args.min_cells, 
        n_Top_genes=args.top_n_genes, K=args.neighbors)
    
    if args.save_fig:
        if args.filename != None:
            save_name = "_" + args.filename

        else:
            save_name = "_" + os.path.splitext(os.path.basename(args.data))[0]
        
        sc.pl.umap(adata_preprocessed, color=['leiden'], save=save_name)
    
    else:
        sc.pl.umap(adata_preprocessed, color=['leiden'], return_fig=True)

    print("\nNumber of predicted clusters: {}\n".format(len(adata_preprocessed.uns['leiden_sizes'])))

    if args.no_save: 
        dir_cwd = os.getcwd()
        dir_processed_data = os.path.join(dir_cwd, "processed_data")
        
        if not os.path.isdir(dir_processed_data):
            print('WARNING: directory "./processed_data" not found.')
            os.mkdir(dir_processed_data)
            print('Directory "./processed_data" is created.\n')

        if args.filename != None:
            filename = args.filename + ".h5ad"
            datafile = os.path.join(dir_processed_data, filename)
        
        elif args.filename == None:
            filename = os.path.splitext(os.path.basename(args.data))[0] + ".h5ad"
            datafile = os.path.join(dir_processed_data, filename)

        # save results of preprocess as AnnData
        if not os.path.isfile(datafile):
            preprocess.writing_adata(adata_preprocessed, datafile)
            print('Preprocessed data are saved in ./processed_data as "{}."\n'.format(filename))
        
        elif os.path.isfile(datafile):
            count = itertools.count(1)
            filename = os.path.splitext(os.path.basename(datafile))[0]

            while os.path.isfile(datafile):
                i = next(count)
                datafile = os.path.join(dir_processed_data, "{0}({1:02d}).h5ad".format(filename, i))
            
            preprocess.writing_adata(adata_preprocessed, datafile)
            print('Preprocessed data are saved in ./processed_data as "{0}({1:02d}).h5ad."\n'.format(filename, i))
        
    print('Preprocess completed.')              
