#!/usr/bin/env python

import argparse
import os
import scanpy as sc
import csv
import numpy as np

import main

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage='./draw_capital.py [option]* <alignment>',
        description='draw_capital.py ver. 0.2.1\n\nRequired packages: leidenalg, scanpy>=1.5 and tslearn.\n\nThis script is used to draw figures on dynamic time warping and/or expression dynamics for a gene in aligned_data.\nUsers have to run capital.py before using this.'
    )
    parser.add_argument('alignment', metavar='alignment <STR>', type=str,
                        help='path to the directory for aligned data generated with capital.py (e.g. ./aligned_data/data1_data2/gene/alignment001)')
    parser.add_argument('--dtw', metavar='<STR>', default=False,
                        help='path to the file for a (e.g. PDF) figure on dynamic time warping')
    parser.add_argument('--dyn', metavar='<STR>', default=False,
                        help='path to the file for a (e.g. PDF) figure on gene expression dynamics')
    parser.add_argument('--data1-name', metavar='<STR>', type=str, default=None,
                        help='data1 name on the plot')
    parser.add_argument('--data2-name', metavar='<STR>', type=str, default=None,
                        help='data2 name on the plot')
    parser.add_argument('-s', '--showfig', action='store_false',
                        help='show the figures of dynamic time warping and gene expression dynamics [on]')
    args = parser.parse_args()

    if args.dtw:
        dir_dtw = os.path.dirname(args.dtw)
        os.makedirs(dir_dtw, exist_ok=True)

    if args.dyn:
        dir_dyn = os.path.dirname(args.dyn)
        os.makedirs(dir_dyn, exist_ok=True)

    alignment_data = np.load(os.path.join(
        args.alignment, "alignment_data.npz"), allow_pickle=True)
    genename = alignment_data["dtwdata"][0][0]
    filtered_data1_file = alignment_data["dtwdata"][1][0]
    filtered_data2_file = alignment_data["dtwdata"][2][0]
    path = alignment_data["dtwdata_path"].tolist()
    cluster_list = alignment_data["dtwdata_cluster"].tolist()

    leidencolors1 = alignment_data["leiden_colors1"].tolist()
    leidencolors1 = alignment_data["leiden_colors2"].tolist()

    data1_fpath = os.path.join(args.alignment, str(filtered_data1_file))
    data2_fpath = os.path.join(args.alignment, str(filtered_data2_file))

    data1 = sc.read(data1_fpath)
    data2 = sc.read(data2_fpath)

    drawing = main.Drawing()
    drawing.draw_dtw_graph(genename, cluster_list, data1, data2, path, leidencolors1, leidencolors1,
                           data1_name=args.data1_name, data2_name=args.data1_name, showfig=args.showfig, save=args.dtw)

    drawing.draw_gene_expression_comparison(genename, cluster_list, data1, data2, path,
                                            data1_name=args.data1_name, data2_name=args.data1_name, showfig=args.showfig, save=args.dyn)
