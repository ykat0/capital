#!/usr/bin/env python

import argparse
import os
import sys
from tqdm import tqdm
import itertools
import networkx as nx
import csv
import numpy as np

import main

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage='./capital.py [option]* <data1> <data2> <root1> <root2> <genes>',
        description='capital.py ver. 0.2.1\n\nRequired packages: leidenalg, scanpy>=1.5 and tslearn.\n\nThis script is used to predict pseudotime trajectories for two preprocessed data and compute a trajectory alignment.\nUsers have to run pre_capital.py for each experiment before using this.'
    )
    parser.add_argument('data1', metavar='data1 <STR>', type=str,
                        help='path to the preprocessed expression H5AD data for experiment 1 generated with pre_capital.py')
    parser.add_argument('data2', metavar='data2 <STR>', type=str,
                        help='path to the preprocessed expression H5AD data for experiment 2 generated with pre_capital.py')
    parser.add_argument('root1', metavar='root1 <STR>', type=str,
                        help='root cluster in data1')
    parser.add_argument('root2', metavar='root2 <STR>', type=str,
                        help='root cluster in data2')
    parser.add_argument('genes', metavar='genes <STR>', type=str,
                        help='path to the file that contains gene names to be analyzed (one gene per line)')
    parser.add_argument('-c', '--gapcost', metavar='<FLOAT>', type=float, default=1.0,
                        help='gap cost used to calculate tree alignment [1.0]')
    parser.add_argument('-m', '--n-genes1', metavar='<INT>', type=int, default=2000,
                        help='number of highly variable genes in data1 [2000]')
    parser.add_argument('-n', '--n-genes2', metavar='<INT>', type=int, default=2000,
                        help='number of highly variable genes in data2 [2000]')
    parser.add_argument('-M', '--method', choices=["euclid", "gauss", "paga"], default="euclid",
                        help='method used to calculate a tree [euclid]')
    parser.add_argument('-l', '--local-align', action='store_true',
                        help='calculate dynamic time warping on local alignment [off]')
    parser.add_argument('-t', '--tune', action='store_true',
                        help='tuning mode, which affects naming of the result directory and never saves H5AD data [off]')

    args = parser.parse_args()

    if not os.path.isfile(args.data1):
        print('ERROR: {} does not exit.'.format(args.data1))
        print('Please run pre_capital.py.')
        sys.exit()

    if not os.path.isfile(args.data2):
        print('ERROR: {} does not exit.'.format(args.data2))
        print('Please run pre_capital.py.')
        sys.exit()

    dir_cwd = os.getcwd()

    # ./aligned_data_method if the tuning mode is on
    if args.tune:
        dir_aligned_data = os.path.join(
            dir_cwd, "aligned_data_{}".format(args.method))

        if not os.path.isdir(dir_aligned_data):
            print('WARNING: directory "./aligned_data_{}" not found.'.format(args.method))
            os.mkdir(dir_aligned_data)
            print('Directory "./aligned_data_{}" is created.\n'.format(args.method))

    # ./aligned_data otherwise
    else:
        dir_aligned_data = os.path.join(dir_cwd, "aligned_data")

        if not os.path.isdir(dir_aligned_data):
            print('WARNING: directory "./aligned_data" not found.')
            os.mkdir(dir_aligned_data)
            print('Directory "./aligned_data" is created.\n')

    # Preprocess each data
    preprocess = main.Preprocessing()
    data1 = preprocess.preprocess(args.data1, args.root1, method=args.method)
    data2 = preprocess.preprocess(args.data2, args.root2, method=args.method)

    # Compare data1 with data2 by tree alignment
    comparison = main.Comparison(data1, data2)
    calculated_data = comparison.compareall(
        cost=args.gapcost, N_1=args.n_genes1, N_2=args.n_genes2)

    # ./aligned_data/data1_data2
    data1_dirname = os.path.splitext(os.path.basename(args.data1))[0]
    data2_dirname = os.path.splitext(os.path.basename(args.data2))[0]
    comp_dirname = "{}_{}".format(data1_dirname, data2_dirname)
    dir_comp_temp = os.path.join(dir_aligned_data, comp_dirname)

    # ./aligned_data/data1_data2/param if the tuning mode is on
    if args.tune:
        param_dirname = "r{}_r{}_c{:.2f}_m{}_n{}".format(
            args.root1, args.root2, args.gapcost, args.n_genes1, args.n_genes2)
        dir_comp = os.path.join(dir_comp_temp, param_dirname)

    # ./aligned_data/data1_data2 otherwise
    else:
        dir_comp = dir_comp_temp

    count = itertools.count(1)

    while os.path.isdir(dir_comp):
        if args.tune:
            dir_comp = os.path.join(
                dir_comp_temp, "{0}_{1:02d}".format(param_dirname, next(count)))

        else:
            dir_comp = os.path.join(
                dir_aligned_data, "{0}_{1:02d}".format(comp_dirname, next(count)))

    os.makedirs(dir_comp, exist_ok=True)

    # ./aligned_data/data1_data2/tree_alignment
    dir_tree = os.path.join(dir_comp, "tree_alignment")
    os.makedirs(dir_tree, exist_ok=True)

    nx.readwrite.gexf.write_gexf(
        calculated_data.alignedtree, "{}/aligned_tree.gexf".format(dir_tree))
    calculated_data.treedistance.to_csv(
        "{}/tree_distance.csv".format(dir_tree))
    calculated_data.forestdistance.to_csv(
        "{}/forest_distance.csv".format(dir_tree))
    calculated_data.cluster_centroid1.to_csv(
        "{}/cluster_centroid1.csv".format(dir_tree))
    calculated_data.cluster_centroid2.to_csv(
        "{}/cluster_centroid2.csv".format(dir_tree))
    calculated_data.tracetree.to_csv("{}/trace_tree.csv".format(dir_tree))
    nx.readwrite.gexf.write_gexf(data1.tree, "{}/tree1.gexf".format(dir_tree))
    nx.readwrite.gexf.write_gexf(data2.tree, "{}/tree2.gexf".format(dir_tree))
    calculated_data.traceforest.to_csv("{}/trace_forest.csv".format(dir_tree))

    with open("{}/alignment_cost.txt".format(dir_tree), 'w') as g:
        g.write("Distance per cluster: {:.3f}\n".format(
            calculated_data.alignmentcost))
        g.write("Number of genes used to caululate cost of the tree alignment: {}\n".format(
            calculated_data.num_gene))

    print("Computing dynamic time warping for each gene.")

    with open(args.genes, 'r') as f:
        genes = [s.strip() for s in f.readlines()]

        for gene in tqdm(genes, desc='Progress'):
            if not gene in data1.rawdata_fullgene.var_names:
                print("WARNING: {} does not exist in {}.".format(
                    gene, data1_dirname))
                continue

            if not gene in data2.rawdata_fullgene.var_names:
                print("WARNING: {} does not exist in {}.".format(
                    gene, data2_dirname))
                continue

            dtw = main.DynamicTimeWarping()
            results = dtw.dpt_dtw(
                data1, data2, calculated_data.alignedtree, gene, localalign=args.local_align)

            # ./aligned_data/data1_data2/gene
            dir_gene = os.path.join(dir_comp, gene)
            os.makedirs(dir_gene, exist_ok=True)

            # ./aligned_data/data1_data2/gene/alignment00X
            count = itertools.count(1)
            dir_alignment = os.path.join(
                dir_gene, "alignment{:03d}".format(next(count)))

            for result in results:
                while os.path.isdir(dir_alignment):
                    dir_alignment = os.path.join(
                        dir_gene, "alignment{:03d}".format(next(count)))

                os.makedirs(dir_alignment, exist_ok=True)

                genename = result[0]
                dtw_cluster_list = result[1]
                ordered_cells1 = result[2]
                ordered_cells2 = result[3]
                path = result[4]

                dtwdata = np.array([[genename],
                                    ['filtered_{}.h5ad'.format(data1_dirname)],
                                    ['filtered_{}.h5ad'.format(data2_dirname)]])

                np.savez_compressed("{}/alignment_data".format(dir_alignment),
                                    dtwdata=dtwdata,
                                    dtwdata_cluster=np.array(dtw_cluster_list),
                                    dtwdata_path=np.array(path),
                                    leiden_colors1=data1.uns["leiden_colors"],
                                    leiden_colors2=data2.uns["leiden_colors"],)

                if not args.tune:
                    ordered_cells1.write(
                        "{}/filtered_{}.h5ad".format(dir_alignment, data1_dirname), compression='gzip')
                    ordered_cells2.write(
                        "{}/filtered_{}.h5ad".format(dir_alignment, data2_dirname), compression='gzip')

    print("\nCAPITAL completed.")
