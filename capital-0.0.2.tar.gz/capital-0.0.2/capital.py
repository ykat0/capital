#!/usr/bin/env python

import core

class CAPITAL:
    def __init__(self):
        pass
    
    def preprocess(self,filename,transepose = False, source_node = None):
        preprocessing = Preprocessing()
        
        if source_node == None:
            data = preprocessing.preprocess(filename, T = transepose)
        else:
            data = preprocessing.preprocess(filename,T = transepose, source_cluster = source_node)
            
        return data
    
        
    def preprocessall(self, filename1, filename2):
        preprocessing = Preprocessing()
        data1 = preprocessing.preprocess(filename1)
        data2 = preprocessing.preprocess(filename2)
    
        return data1,data2
    
    def compare(self, data1, data2, cost,N):
        comparison = Comparison(data1,data2)
        calculated_data =  comparison.compareall(cost,N)

        return calculated_data
          
    def dtw(self, data1, data2, alignedtree, genename,localalignment = False):
        dtw = DynamicTimeWarping()
        result = dtw.dtw_all(data1, data2, alignedtree, genename,localalign = localalignment)
        
        return result
    

    def show_group_comparison_for_gene(self, result, data1_name = None, data2_name = None,polyfit = 6,savegraph = False, switch = False):
        dtw = DynamicTimeWarping()
        for i in result:
            dtw.show_group_comparison_for_gene(i, data1_name=data1_name , data2_name=data2_name,save= savegraph,polyfit_dimention= polyfit,switch_psedotime = switch)
    
    
    def show_dtw_graph(self, result,data1_name = None, data2_name = None,savegraph = False):
        dtw = DynamicTimeWarping()
        for i in result:
            dtw.show_dtw_graph(i, data1_name=data1_name, data2_name=data2_name,save= savegraph)
    
    def fullprocess(self ,filename1, filename2, genename):

        data1, data2 = self.preprocessall(filename1, filename2)
        G, calculated_data = self.compare(data1,data2)
        result_list = self.dtw(data1, data2, G, genename)

        return G, result_list, calculated_data
    
    def search_genes(self, calculated_data):
        data1 = calculated_data.filtered_data1
        data2 = calculated_data.filtered_data2
        
        genelist = []
        for i,j in list(G):
            if data1.obs['louvain'].isin([i]).any() and data2.obs['louvain'].isin([j]).any():
                cluster1 = data1[data1.obs['louvain'] == i].copy()
                cluster2 = data2[data2.obs['louvain'] == j].copy()
                adata = cluster1.concatenate(cluster2)

                sc.tl.rank_genes_groups(adata, 'batch', method='wilcoxon')
                genelist.extend([i for i,j in list(adata.uns['rank_genes_groups']["names"][0:2])])
                genelist.extend([j for i,j in list(adata.uns['rank_genes_groups']["names"][0:2])])
                
        return genelist
    
